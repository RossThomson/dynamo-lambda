# dynamo-lambda

## Depolyment

run `serverless deploy`

## Testing and coverage

run `npm run test`
